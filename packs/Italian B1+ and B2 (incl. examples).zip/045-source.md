Proporre
> Proporranno un rilascio graduale.

> Propongo di coinvolgere artisti locali.
