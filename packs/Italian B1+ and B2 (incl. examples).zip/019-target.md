Cultivate
> Mentors cultivate confidence in younger peers.

> He cultivates rare plants in a rooftop greenhouse.
