Organizzare
> Posso organizzare una visita agli impianti questo pomeriggio.

> Hanno organizzato i documenti in base all’urgenza.
