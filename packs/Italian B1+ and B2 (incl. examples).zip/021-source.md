Dedicare
> Dedica il venerdì alle sessioni di mentoring.

> Dedicamo questa sala agli eventi della comunità.
