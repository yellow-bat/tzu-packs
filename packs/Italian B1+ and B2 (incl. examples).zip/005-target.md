Assert
> She had to assert her independence in the debate.

> The spokesperson asserted that the product is safe.
