Reinforce
> Use concrete beams to reinforce the bridge.

> Leaders reinforce desired habits through recognition.
