Demonstrate
> He will demonstrate the prototype tomorrow.

> The data demonstrate a clear correlation.
