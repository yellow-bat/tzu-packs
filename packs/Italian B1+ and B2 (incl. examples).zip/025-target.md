Emphasize
> Coaches emphasize consistency over speed.

> Please emphasize the cultural impact in your article.
