Incoraggiare
> I supervisori incoraggiano le domande durante la formazione.

> L’hanno incoraggiata a presentare l’idea di ricerca.
