Foresee
> Experts foresee increased demand for green housing.

> I could foresee tension between the two partners.
