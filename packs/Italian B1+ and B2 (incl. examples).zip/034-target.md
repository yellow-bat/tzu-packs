Innovate
> Startups innovate to stay ahead of competitors.

> Our lab innovates in biodegradable materials.
