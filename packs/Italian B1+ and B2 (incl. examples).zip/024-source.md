Dimostrare
> Domani dimostrerà il prototipo.

> I dati dimostrano una correlazione evidente.
