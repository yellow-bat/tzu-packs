Valutare
> Valutiamo i fornitori due volte l’anno.

> Ha valutato il programma pilota con sondaggi accurati.
