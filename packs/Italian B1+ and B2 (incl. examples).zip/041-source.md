Organizzare
> Organizzerà gli archivi per decennio.

> Organizziamo un briefing prima dell’udienza.
