Calculate
> Please calculate the total cost including maintenance.

> The navigator calculates the safest route automatically.
