Regulate
> Agencies regulate the use of shared frequencies.

> The city regulates outdoor advertising.
