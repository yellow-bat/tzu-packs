Rafforzare
> Usa travi in cemento per rafforzare il ponte.

> I leader rafforzano le abitudini desiderate con il riconoscimento.
