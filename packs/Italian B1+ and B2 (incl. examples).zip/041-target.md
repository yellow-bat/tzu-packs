Organize
> She will organize the archives by decade.

> Let’s organize a briefing before the hearing.
