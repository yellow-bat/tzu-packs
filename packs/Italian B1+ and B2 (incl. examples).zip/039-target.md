Negotiate
> Both unions negotiate together for better benefits.

> We negotiated a clause that protects freelancers.
