Expand
> The gallery will expand its collection in 2026.

> They expanded the curriculum with digital skills.
