Assume
> We should not assume that everyone knows the policy.

> I assume the tickets were booked in advance.
