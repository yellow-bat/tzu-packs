Interpret
> Only experts can interpret these seismic signals.

> She interpreted the poem as a call for change.
