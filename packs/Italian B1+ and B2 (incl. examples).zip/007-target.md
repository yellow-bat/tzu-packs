Assist
> A mentor will assist you throughout the internship.

> The engineer assisted the client remotely.
