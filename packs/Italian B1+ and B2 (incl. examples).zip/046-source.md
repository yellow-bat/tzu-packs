Consigliare
> Gli esperti consigliano di far riposare il motore tra un viaggio e l’altro.

> Quale corso consiglieresti ai nuovi manager?
