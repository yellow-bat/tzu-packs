Coordinate
> We need someone to coordinate the volunteers.

> They coordinated shipments across three ports.
