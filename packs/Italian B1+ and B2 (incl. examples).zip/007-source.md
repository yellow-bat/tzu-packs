Assistere
> Un mentore ti assisterà per tutta la durata dello stage.

> L’ingegnere ha assistito il cliente da remoto.
