Indagare
> Gli ispettori indagheranno sulla causa del blackout.

> I giornalisti hanno indagato sulle affermazioni in modo indipendente.
