Propose
> They will propose a phased rollout.

> I propose that we involve local artists.
