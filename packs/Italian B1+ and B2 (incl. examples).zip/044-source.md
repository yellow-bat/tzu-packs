Dare priorità
> Dai priorità prima ai ticket di manutenzione urgenti.

> Dà priorità alla chiarezza quando scrive istruzioni.
