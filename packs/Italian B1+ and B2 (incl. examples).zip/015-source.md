Concludere
> Possiamo concludere la sessione dopo le domande e risposte.

> Il giudice ha concluso che le accuse erano infondate.
