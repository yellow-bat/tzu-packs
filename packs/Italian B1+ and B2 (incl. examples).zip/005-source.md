Affermare
> Ha dovuto affermare la propria indipendenza nel dibattito.

> Il portavoce ha affermato che il prodotto è sicuro.
