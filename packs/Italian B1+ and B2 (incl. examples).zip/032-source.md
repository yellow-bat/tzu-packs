Attuare
> Attueremo il nuovo protocollo il prossimo trimestre.

> L’associazione ha attuato regole di rendicontazione più rigide.
