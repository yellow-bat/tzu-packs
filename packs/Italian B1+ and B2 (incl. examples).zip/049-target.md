Summarize
> Please summarize the findings in two paragraphs.

> She summarized the novel without spoilers.
