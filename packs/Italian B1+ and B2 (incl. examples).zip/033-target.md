Improve
> The upgrade should improve battery life significantly.

> She improved her pronunciation through daily practice.
