Dedicate
> She dedicates Fridays to mentoring sessions.

> We dedicate this hall to community events.
