Compare
> Compare the two contracts line by line.

> We compared delivery times across suppliers.
