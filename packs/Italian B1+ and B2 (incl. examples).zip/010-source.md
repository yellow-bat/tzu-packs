Calcolare
> Per favore calcola il costo totale compresa la manutenzione.

> Il navigatore calcola automaticamente il percorso più sicuro.
