Interpretare
> Solo gli esperti possono interpretare questi segnali sismici.

> Ha interpretato la poesia come un invito al cambiamento.
