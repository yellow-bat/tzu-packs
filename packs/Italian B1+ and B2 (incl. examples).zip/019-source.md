Coltivare
> I mentori coltivano la fiducia nei colleghi più giovani.

> Coltiva piante rare in una serra sul tetto.
