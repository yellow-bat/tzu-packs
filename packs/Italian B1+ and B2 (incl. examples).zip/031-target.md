Foster
> These retreats foster collaboration across teams.

> Reading circles foster empathy among students.
