Anticipate
> We anticipate heavier traffic during the festival.

> Try to anticipate questions the investors might ask.
