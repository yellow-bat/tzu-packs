Riassumere
> Per favore riassumi i risultati in due paragrafi.

> Ha riassunto il romanzo senza svelare la trama.
