Analizzare
> Gli scienziati analizzano i campioni prima di trarre conclusioni.

> Per favore analizza i feedback e metti in evidenza i temi ricorrenti.
