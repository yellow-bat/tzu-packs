Giustificare
> Ha faticato a giustificare le spese impreviste.

> Per favore giustifica perché la scadenza deve essere spostata.
