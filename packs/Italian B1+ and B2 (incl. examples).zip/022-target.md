Define
> Our charter defines the limits of authority.

> Please define the success metrics clearly.
