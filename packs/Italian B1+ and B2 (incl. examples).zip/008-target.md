Attempt
> He will attempt the certification exam again in spring.

> They attempted to resolve the issue overnight.
