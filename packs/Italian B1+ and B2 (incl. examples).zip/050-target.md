Sustain
> Can we sustain this pace through winter?

> The fund sustains several cultural institutions.
