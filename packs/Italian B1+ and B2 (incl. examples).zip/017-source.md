Convincere
> Dati concreti hanno aiutato a convincere il consiglio scettico.

> Ha convinto la collega a partecipare al workshop.
