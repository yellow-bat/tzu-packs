Prioritize
> Prioritize urgent maintenance tickets first.

> She prioritizes clarity when writing instructions.
