Assicurare
> Ricontrolla i cablaggi per assicurare la sicurezza.

> I revisori assicurano che le procedure vengano seguite.
