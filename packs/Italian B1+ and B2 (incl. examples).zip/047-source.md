Regolamentare
> Le agenzie regolamentano l’uso delle frequenze condivise.

> La città regolamenta la pubblicità esterna.
