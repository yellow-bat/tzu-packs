Ensure
> Double-check the wiring to ensure safety.

> Auditors ensure that procedures are followed.
