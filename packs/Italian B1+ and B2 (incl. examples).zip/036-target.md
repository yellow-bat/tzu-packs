Investigate
> Inspectors will investigate the cause of the outage.

> Journalists investigated the claims independently.
