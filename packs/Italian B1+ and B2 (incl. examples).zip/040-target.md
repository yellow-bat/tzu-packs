Observe
> Teachers observe lessons to provide feedback.

> We observed unusual patterns in the logs.
