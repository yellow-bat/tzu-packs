Coordinare
> Ci serve qualcuno che coordini i volontari.

> Hanno coordinato le spedizioni in tre porti.
