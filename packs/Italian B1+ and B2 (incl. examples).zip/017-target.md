Convince
> Hard data helped convince the skeptical board.

> She convinced her colleague to join the workshop.
