Conclude
> We can conclude the session after the Q&A.

> The judge concluded that the charges were unfounded.
