Maintain
> It is hard to maintain focus during long hearings.

> They maintain the trail with weekly inspections.
