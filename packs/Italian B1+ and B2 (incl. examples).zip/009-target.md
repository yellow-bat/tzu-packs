Balance
> She balances study commitments with part-time work.

> Let’s balance innovation with reliable procedures.
