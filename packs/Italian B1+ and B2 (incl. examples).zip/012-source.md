Collaborare
> Due università collaborano al progetto sul clima.

> Incoraggiamo i team a collaborare oltre i reparti.
