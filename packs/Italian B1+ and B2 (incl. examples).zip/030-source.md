Prevedere
> Gli esperti prevedono una maggiore domanda di case ecologiche.

> Riuscivo a prevedere tensione tra i due soci.
