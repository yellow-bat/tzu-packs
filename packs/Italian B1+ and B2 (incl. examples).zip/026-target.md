Encourage
> Supervisors encourage questions during training.

> They encouraged her to submit the research idea.
