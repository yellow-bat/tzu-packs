Clarify
> I will clarify the expectations during our call.

> Could you clarify what evidence supports this claim?
