Delegate
> Effective leaders delegate tasks with context.

> She delegated budget reviews to a senior analyst.
