Supporre
> Non dovremmo supporre che tutti conoscano la politica.

> Suppongo che i biglietti siano stati prenotati in anticipo.
