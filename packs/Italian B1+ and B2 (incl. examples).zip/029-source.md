Espandere
> La galleria espanderà la sua collezione nel 2026.

> Hanno espanso il curriculum con competenze digitali.
