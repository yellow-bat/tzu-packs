Delegare
> I leader efficaci delegano i compiti fornendo contesto.

> Ha delegato le revisioni di budget a un analista senior.
