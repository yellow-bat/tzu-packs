Combine
> Combine practical exercises with theoretical study.

> The recipe combines sweet fruit with spicy herbs.
