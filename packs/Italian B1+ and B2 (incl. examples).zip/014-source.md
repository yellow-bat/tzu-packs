Confrontare
> Confronta i due contratti riga per riga.

> Abbiamo confrontato i tempi di consegna dei fornitori.
