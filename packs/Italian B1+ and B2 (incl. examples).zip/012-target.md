Collaborate
> Two universities collaborate on the climate project.

> We encourage teams to collaborate beyond departments.
