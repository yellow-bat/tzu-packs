Tentare
> Tenterà di nuovo l’esame di certificazione in primavera.

> Hanno tentato di risolvere il problema durante la notte.
