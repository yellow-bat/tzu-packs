Partecipare
> I residenti partecipano ai laboratori sul bilancio.

> Partecipa a ogni retrospettiva.
