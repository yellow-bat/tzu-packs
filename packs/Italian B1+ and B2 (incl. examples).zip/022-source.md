Definire
> Il nostro statuto definisce i limiti dell’autorità.

> Per favore definisci chiaramente gli indicatori di successo.
