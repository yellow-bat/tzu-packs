Conserve
> Install smart meters to conserve water.

> They conserve documents in a climate-controlled vault.
