Justify
> He struggled to justify the unexpected expenses.

> Please justify why the deadline must be moved.
