Anticipare
> Anticipiamo un traffico più intenso durante il festival.

> Cerca di anticipare le domande che gli investitori potrebbero fare.
