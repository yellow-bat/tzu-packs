Predire
> Puoi predire come reagirà il pubblico?

> Gli analisti hanno predetto una crescita costante per il settore.
