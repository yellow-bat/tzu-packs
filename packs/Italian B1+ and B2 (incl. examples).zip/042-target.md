Participate
> Residents participate in budgeting workshops.

> He participates in every retrospective.
