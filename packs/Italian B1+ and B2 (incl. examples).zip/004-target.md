Arrange
> I can arrange a tour of the facilities this afternoon.

> They arranged the documents by urgency.
