Debate
> Parliament will debate the reform this evening.

> We debated whether to automate the manual checks.
