Osservare
> Gli insegnanti osservano le lezioni per dare feedback.

> Abbiamo osservato schemi insoliti nei registri.
