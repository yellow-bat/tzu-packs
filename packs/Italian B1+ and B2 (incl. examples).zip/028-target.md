Evaluate
> We evaluate suppliers twice a year.

> She evaluated the pilot program with careful surveys.
