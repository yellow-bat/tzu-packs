Dibattere
> Il parlamento dibatterà la riforma questa sera.

> Abbiamo dibattuto se automatizzare i controlli manuali.
