Implement
> We will implement the new protocol next quarter.

> The charity implemented stricter reporting rules.
