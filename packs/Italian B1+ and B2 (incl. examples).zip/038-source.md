Mantenere
> È difficile mantenere la concentrazione durante lunghe udienze.

> Mantengono il sentiero con ispezioni settimanali.
