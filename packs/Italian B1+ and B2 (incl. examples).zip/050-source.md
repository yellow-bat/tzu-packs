Sostenere
> Possiamo sostenere questo ritmo per tutto l’inverno?

> Il fondo sostiene diverse istituzioni culturali.
