Migliorare
> L’aggiornamento dovrebbe migliorare notevolmente la durata della batteria.

> Ha migliorato la pronuncia con esercizi quotidiani.
