Chiarire
> Chiarirò le aspettative durante la nostra chiamata.

> Potresti chiarire quali prove sostengono questa affermazione?
