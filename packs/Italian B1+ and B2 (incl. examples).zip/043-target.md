Predict
> Can you predict how the audience will react?

> Analysts predicted steady growth for the sector.
